import { useState, useRef, useEffect } from 'react';
import { Mic, MicOff, Square, Play, FileText, Volume2, Settings, Download, Brain, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { CommandAnalysisRequest, CommandAnalysisResponse, AIError } from '@shared/ai-commands';
import { MultiAIConfigDialog } from '@/components/MultiAIConfigDialog';

type VoiceStatus = 'inactive' | 'listening' | 'processing' | 'active';

interface Command {
  type: 'insert' | 'delete' | 'replace' | 'format';
  content?: string;
  target?: string;
  replacement?: string;
}

export default function Index() {
  const [isListening, setIsListening] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState<VoiceStatus>('inactive');
  const [transcript, setTranscript] = useState('');
  const [documentContent, setDocumentContent] = useState('');
  const [lastCommand, setLastCommand] = useState<string>('');
  const [lastAnalysis, setLastAnalysis] = useState<CommandAnalysisResponse | null>(null);
  const [isContinuousMode, setIsContinuousMode] = useState(false);
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [aiStatus, setAiStatus] = useState<'ready' | 'processing' | 'error' | 'unavailable'>('ready');
  const [aiProviders, setAiProviders] = useState<string[]>([]);
  const [providerStatus, setProviderStatus] = useState<any>(null);
  const [selectedProvider, setSelectedProvider] = useState<string>('auto');
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const { toast } = useToast();

  // Check AI status on mount
  useEffect(() => {
    const checkAIStatus = async () => {
      try {
        // First check ping endpoint
        const pingResponse = await fetch('/api/ping', {
          method: 'GET',
          headers: { 'Accept': 'application/json' }
        });

        if (!pingResponse.ok) {
          throw new Error(`Ping failed: ${pingResponse.status}`);
        }

        const pingData = await pingResponse.json();
        setAiProviders(pingData.providers || []);

        // Then check AI status with timeout
        try {
          const statusController = new AbortController();
          const statusTimeout = setTimeout(() => statusController.abort(), 15000); // 15 second timeout

          const statusResponse = await fetch('/api/ai-status', {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
            signal: statusController.signal
          });

          clearTimeout(statusTimeout);

          if (statusResponse.ok) {
            const statusData = await statusResponse.json();
            setProviderStatus(statusData);

            if (statusData.totalWorking > 0) {
              setAiStatus('ready');
            } else if (statusData.totalAvailable > 0) {
              setAiStatus('error');
            } else {
              setAiStatus('unavailable');
            }
          } else {
            console.warn('AI status endpoint failed:', statusResponse.status);
            setAiStatus(pingData.providers?.length > 0 ? 'error' : 'unavailable');
          }
        } catch (statusError) {
          console.warn('AI status check failed:', statusError);
          // Still set basic status based on ping
          setAiStatus(pingData.providers?.length > 0 ? 'error' : 'unavailable');
        }

      } catch (error) {
        console.error('Failed to check AI status:', error);
        setAiStatus('unavailable');
        setAiProviders([]);
        toast({
          title: "خطأ في الاتصال",
          description: "لم يتمكن من التحقق من حالة الذكاء الاصطناعي",
          variant: "destructive",
        });
      }
    };

    checkAIStatus();
  }, [toast]);

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      
      const recognition = recognitionRef.current;
      recognition.lang = 'ar-SA';
      recognition.continuous = true;
      recognition.interimResults = true;

      recognition.onstart = () => {
        setVoiceStatus('listening');
        setIsListening(true);
      };

      recognition.onresult = (event) => {
        setVoiceStatus('processing');
        let finalTranscript = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        
        if (finalTranscript) {
          setTranscript(finalTranscript);
          processVoiceInput(finalTranscript);
        }
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setVoiceStatus('inactive');
        setIsListening(false);
        toast({
          title: "خطأ في التعرف على الصوت",
          description: "حدث خطأ أثناء التعرف على الصوت. يرجى المحاولة مرة أخرى.",
          variant: "destructive",
        });
      };

      recognition.onend = () => {
        setVoiceStatus('inactive');
        setIsListening(false);
        if (isContinuousMode) {
          // Restart recognition in continuous mode
          setTimeout(() => startListening(), 100);
        }
      };
    } else {
      toast({
        title: "المتصفح غير مدعوم",
        description: "متصفحك لا يدعم التعرف على الصوت. يرجى استخدام Chrome أو Edge.",
        variant: "destructive",
      });
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [isContinuousMode]);

  const processVoiceInput = async (input: string) => {
    const cleanInput = input.trim();
    setLastCommand(cleanInput);
    setCommandHistory(prev => [cleanInput, ...prev.slice(0, 9)]);

    // Quick check for stop command (bypass AI for immediate response)
    if (cleanInput.includes('ت��قف') || cleanInput.includes('إيقاف')) {
      stopListening();
      setIsContinuousMode(false);
      toast({
        title: "تم الإيقاف",
        description: "تم إيقاف التسجيل الصوتي.",
      });
      return;
    }

    // Quick check for continuous mode activation
    if (cleanInput.includes('استمرار') || cleanInput.includes('وضع مستمر')) {
      setIsContinuousMode(true);
      toast({
        title: "الوضع المستمر",
        description: "تم تفعيل الوضع المستمر. قل 'توقف' للإيقاف.",
      });
      return;
    }

    // Use AI to analyze the command
    try {
      setAiStatus('processing');
      const analysis = await analyzeWithAI(cleanInput);
      setLastAnalysis(analysis);

      if (analysis.isCommand) {
        await executeAICommand(analysis, cleanInput);
      } else {
        insertText(analysis.content || cleanInput);
      }

      setAiStatus('ready');
      toast({
        title: analysis.isCommand ? "تم تنفيذ الأمر" : "تم إدراج النص",
        description: analysis.explanation,
      });

    } catch (error) {
      console.error('AI analysis failed:', error);
      setAiStatus('error');

      // Fallback to basic detection
      const command = detectCommand(cleanInput);
      if (command) {
        executeCommand(command, cleanInput);
      } else {
        insertText(cleanInput);
      }

      toast({
        title: "تم استخدام التحليل الأساسي",
        description: "فشل الذكاء الاصطناعي، تم استخدام التحليل الأساسي",
        variant: "destructive",
      });
    }

    setVoiceStatus('active');
    setTimeout(() => setVoiceStatus('inactive'), 1000);
  };

  const analyzeWithAI = async (text: string): Promise<CommandAnalysisResponse> => {
    const requestData: CommandAnalysisRequest = {
      text,
      context: documentContent.slice(-200) // Last 200 characters for context
    };

    // Choose endpoint based on selected provider
    const endpoint = selectedProvider === 'auto'
      ? '/api/analyze-command'
      : `/api/analyze-with/${selectedProvider}`;

    // Add timeout to AI requests
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000); // 30 second timeout

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify(requestData),
        signal: controller.signal,
      });

      clearTimeout(timeout);

      if (!response.ok) {
        let errorMessage = 'فشل في تحليل الأمر';
        try {
          const errorData: AIError = await response.json();
          errorMessage = errorData.message || errorMessage;
        } catch (parseError) {
          console.warn('Failed to parse error response');
        }
        throw new Error(errorMessage);
      }

      return response.json();
    } catch (error) {
      clearTimeout(timeout);
      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          throw new Error('انتهت مهلة الانتظار - يرجى المحاولة مرة أخرى');
        }
        throw error;
      }
      throw new Error('خطأ غير متوقع في التحلي��');
    }
  };

  const executeAICommand = async (analysis: CommandAnalysisResponse, originalText: string) => {
    switch (analysis.commandType) {
      case 'delete':
        if (analysis.target === 'all') {
          if (window.confirm('هل أنت متأكد من حذف جميع المحتوى؟')) {
            setDocumentContent('');
          }
        } else if (analysis.target === 'last') {
          const lines = documentContent.split('\n');
          if (lines.length > 0) {
            lines.pop();
            setDocumentContent(lines.join('\n'));
          }
        }
        break;

      case 'format':
        if (analysis.content) {
          setDocumentContent(prev => prev + (prev ? '\n\n' : '') + `# ${analysis.content}\n`);
        }
        break;

      case 'insert':
        if (analysis.content) {
          insertText(analysis.content);
        }
        break;

      case 'replace':
        // For now, just insert the replacement text
        if (analysis.replacement) {
          insertText(analysis.replacement);
        }
        break;

      case 'control':
        if (analysis.action.includes('إيقاف')) {
          stopListening();
          setIsContinuousMode(false);
        } else if (analysis.action.includes('مستمر')) {
          setIsContinuousMode(true);
        }
        break;

      default:
        insertText(analysis.content || originalText);
    }
  };

  const detectCommand = (input: string): Command | null => {
    const text = input.toLowerCase();
    
    // Delete commands
    if (text.includes('امسح') || text.includes('احذف') || text.includes('إزالة')) {
      if (text.includes('آخر') || text.includes('أخير')) {
        return { type: 'delete', target: 'last' };
      }
      if (text.includes('كل') || text.includes('جميع')) {
        return { type: 'delete', target: 'all' };
      }
      return { type: 'delete', target: 'selection' };
    }
    
    // Replace commands
    if (text.includes('استبدل') || text.includes('غير')) {
      return { type: 'replace' };
    }
    
    // Format commands
    if (text.includes('عنوان') || text.includes('رأس')) {
      return { type: 'format', content: 'heading' };
    }
    
    // Add commands
    if (text.includes('أضف') || text.includes('اكتب')) {
      return { type: 'insert' };
    }
    
    return null;
  };

  const executeCommand = (command: Command, originalText: string) => {
    switch (command.type) {
      case 'delete':
        if (command.target === 'all') {
          if (window.confirm('هل أنت متأكد من حذف جميع المحتوى؟')) {
            setDocumentContent('');
            toast({ title: "تم حذف المحتوى", description: "تم حذف جميع المحتوى." });
          }
        } else if (command.target === 'last') {
          const lines = documentContent.split('\n');
          if (lines.length > 0) {
            lines.pop();
            setDocumentContent(lines.join('\n'));
            toast({ title: "تم الحذف", description: "تم حذف آخر سطر." });
          }
        }
        break;
        
      case 'format':
        if (command.content === 'heading') {
          const textToAdd = originalText.replace(/.*عنوان/i, '').trim();
          if (textToAdd) {
            setDocumentContent(prev => prev + (prev ? '\n\n' : '') + `# ${textToAdd}\n`);
            toast({ title: "تم إضافة العنوان", description: `تم إضافة العنوان: ${textToAdd}` });
          }
        }
        break;
        
      case 'insert':
        const textToInsert = originalText.replace(/^(أضف|اكتب)\s*/i, '').trim();
        if (textToInsert) {
          insertText(textToInsert);
        }
        break;
        
      default:
        insertText(originalText);
    }
  };

  const insertText = (text: string) => {
    setDocumentContent(prev => {
      const newContent = prev + (prev && !prev.endsWith('\n') ? ' ' : '') + text;
      return newContent;
    });
    
    toast({
      title: "تم إدراج النص",
      description: `تم إدراج: ${text.substring(0, 30)}${text.length > 30 ? '...' : ''}`,
    });
  };

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      recognitionRef.current.start();
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
    }
  };

  const toggleListening = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  const downloadDocument = () => {
    if (!documentContent.trim()) {
      toast({
        title: "لا يوجد محتوى",
        description: "لا يوجد محتوى لتنزيله.",
        variant: "destructive",
      });
      return;
    }

    const blob = new Blob([documentContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `مستند-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: "تم التنزيل",
      description: "تم تنزيل المستند بنجاح.",
    });
  };

  const getStatusText = (status: VoiceStatus) => {
    switch (status) {
      case 'listening': return 'أستمع...';
      case 'processing': return 'أعالج...';
      case 'active': return 'تم التنفيذ';
      default: return 'غير نشط';
    }
  };

  const getStatusColor = (status: VoiceStatus) => {
    switch (status) {
      case 'listening': return 'voice-listening';
      case 'processing': return 'voice-processing'; 
      case 'active': return 'voice-active';
      default: return 'voice-inactive';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Brain className="w-8 h-8 text-blue-600" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white arabic-text">
              مساعد الوثائق الصوتي بالذكاء الاصطناعي
            </h1>
          </div>
          <p className="text-lg text-gray-600 dark:text-gray-300 arabic-text">
            اكتب وحرر الوثائق باستخدام صوتك باللغة العربية مع تحليل ذكي للأوامر
          </p>

          {/* AI Status Indicator */}
          <div className="flex flex-col items-center gap-3 mt-4">
            <div className="flex items-center gap-2">
              <Badge
                variant={aiStatus === 'ready' ? 'default' : aiStatus === 'processing' ? 'secondary' : 'destructive'}
                className="arabic-text"
              >
                {aiStatus === 'ready' && (
                  <>
                    <Zap className="w-3 h-3 ml-1" />
                    {aiProviders.length > 0 ? `🤖 متاح ${aiProviders.length} مقدم خدمة` : 'الذكاء الاصطناعي جاهز'}
                  </>
                )}
                {aiStatus === 'processing' && (
                  <>
                    <Brain className="w-3 h-3 ml-1 animate-pulse" />
                    يحلل الأمر...
                  </>
                )}
                {aiStatus === 'error' && (
                  <>
                    ⚠️ خطأ في الذكاء الاصطناعي
                  </>
                )}
                {aiStatus === 'unavailable' && (
                  <>
                    ��� الذكاء الاصطناعي غير متاح
                  </>
                )}
              </Badge>

              <MultiAIConfigDialog
                aiStatus={providerStatus}
                selectedProvider={selectedProvider}
                onProviderSelect={setSelectedProvider}
                onConfigUpdate={() => {
                  // Refresh status after config update
                  window.location.reload();
                }}
              />
            </div>

            {/* Show available providers and selection */}
            {aiProviders.length > 0 && (
              <div className="flex flex-col gap-2 text-xs">
                <div className="flex flex-wrap gap-1">
                  {aiProviders.map((provider, idx) => (
                    <Badge key={idx} variant="outline" className="text-xs">
                      {provider}
                    </Badge>
                  ))}
                </div>

                {selectedProvider !== 'auto' && (
                  <div className="flex items-center gap-2">
                    <Badge variant="default" className="text-xs arabic-text">
                      الخدمة المحددة: {selectedProvider}
                    </Badge>
                    <Button
                      onClick={() => setSelectedProvider('auto')}
                      variant="outline"
                      size="sm"
                      className="h-6 px-2 text-xs arabic-text"
                    >
                      تلقائي
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Voice Control Panel */}
          <div className="lg:col-span-1">
            <Card className="h-fit">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 arabic-text">
                  <Volume2 className="w-5 h-5" />
                  التحكم الصوتي
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Voice Status */}
                <div className="text-center">
                  <div className={`w-24 h-24 mx-auto rounded-full border-4 border-${getStatusColor(voiceStatus)} flex items-center justify-center mb-4 transition-all duration-300 ${voiceStatus !== 'inactive' ? 'pulse-voice' : ''}`}>
                    {isListening ? (
                      <Mic className="w-8 h-8 text-blue-600" />
                    ) : (
                      <MicOff className="w-8 h-8 text-gray-400" />
                    )}
                  </div>
                  <Badge 
                    variant={voiceStatus === 'inactive' ? 'secondary' : 'default'}
                    className="text-sm arabic-text"
                  >
                    {getStatusText(voiceStatus)}
                  </Badge>
                </div>

                {/* Control Buttons */}
                <div className="flex flex-col gap-3">
                  <Button 
                    onClick={toggleListening}
                    className={`w-full h-12 text-base arabic-text ${
                      isListening 
                        ? 'bg-red-500 hover:bg-red-600' 
                        : 'bg-blue-500 hover:bg-blue-600'
                    }`}
                  >
                    {isListening ? (
                      <>
                        <Square className="w-5 h-5 ml-2" />
                        إيقاف التسجيل
                      </>
                    ) : (
                      <>
                        <Play className="w-5 h-5 ml-2" />
                        بدء التسجيل
                      </>
                    )}
                  </Button>

                  <Button 
                    onClick={() => setIsContinuousMode(!isContinuousMode)}
                    variant={isContinuousMode ? "default" : "outline"}
                    className="w-full arabic-text"
                  >
                    الوضع المستمر {isContinuousMode ? '(مفعل)' : '(معطل)'}
                  </Button>
                </div>

                {/* Last Command */}
                {lastCommand && (
                  <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <p className="text-sm text-gray-600 dark:text-gray-300 mb-1">آخر أمر:</p>
                    <p className="text-sm font-medium arabic-text">{lastCommand}</p>
                  </div>
                )}

                {/* AI Analysis */}
                {lastAnalysis && (
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <div className="flex items-center gap-2 mb-2">
                      <Brain className="w-4 h-4 text-blue-600" />
                      <p className="text-sm font-medium text-blue-800 dark:text-blue-200 arabic-text">
                        تحليل الذكاء الاصطناعي
                      </p>
                      <Badge variant={lastAnalysis.isCommand ? "default" : "secondary"} className="text-xs">
                        {lastAnalysis.isCommand ? "أمر" : "نص"}
                      </Badge>
                    </div>
                    <div className="space-y-1 text-xs text-blue-700 dark:text-blue-300 arabic-text">
                      <p><strong>العمل:</strong> {lastAnalysis.action}</p>
                      <p><strong>الثقة:</strong> {Math.round(lastAnalysis.confidence * 100)}%</p>
                      <p><strong>التفسير:</strong> {lastAnalysis.explanation}</p>
                    </div>
                  </div>
                )}

                {/* Command History */}
                {commandHistory.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 arabic-text">
                      سجل الأوامر
                    </h4>
                    <div className="max-h-32 overflow-y-auto arabic-scroll space-y-1">
                      {commandHistory.slice(0, 5).map((cmd, idx) => (
                        <div key={idx} className="text-xs p-2 bg-gray-50 dark:bg-gray-800 rounded text-gray-600 dark:text-gray-400 arabic-text">
                          {cmd}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Document Editor */}
          <div className="lg:col-span-2">
            <Card className="h-[600px] flex flex-col">
              <CardHeader className="flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2 arabic-text">
                  <FileText className="w-5 h-5" />
                  محرر الوثيقة
                </CardTitle>
                <div className="flex gap-2">
                  <Button 
                    onClick={downloadDocument}
                    variant="outline"
                    size="sm"
                    className="arabic-text"
                  >
                    <Download className="w-4 h-4 ml-1" />
                    تنزيل
                  </Button>
                  <Button 
                    onClick={() => setDocumentContent('')}
                    variant="outline" 
                    size="sm"
                    className="arabic-text"
                  >
                    مسح الكل
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col">
                <div className="flex-1 border rounded-lg">
                  <Textarea
                    value={documentContent}
                    onChange={(e) => setDocumentContent(e.target.value)}
                    className="w-full h-full resize-none border-0 arabic-text arabic-scroll text-lg leading-relaxed"
                    placeholder="ابدأ الحديث أو اكتب هنا... سيظهر النص المُدخل بالصوت هنا تلقائياً"
                    dir="rtl"
                  />
                </div>
                
                {/* Document Stats */}
                <div className="mt-4 flex justify-between text-sm text-gray-500 arabic-text">
                  <span>عدد الكلمات: {documentContent.trim().split(/\s+/).filter(word => word.length > 0).length}</span>
                  <span>عدد الأحرف: {documentContent.length}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Quick Commands Guide */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="arabic-text flex items-center gap-2">
              <Brain className="w-5 h-5" />
              دليل الأوامر الذكية
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
              <p className="text-sm text-blue-800 dark:text-blue-200 arabic-text">
                <Brain className="w-4 h-4 inline ml-1" />
                <strong>مع الذكاء الاصطناعي:</strong> يمكنك استخدام أي صياغة طبيعية باللغة العربية.
                النظام سيفهم مقصدك ويحلل الأمر بذكاء.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm arabic-text">
              <div className="space-y-2">
                <h4 className="font-semibold text-blue-600">أوامر الحذف</h4>
                <ul className="space-y-1 text-gray-600 dark:text-gray-300">
                  <li>• "امسح الفقرة الأخيرة"</li>
                  <li>• "احذف كل شيء"</li>
                  <li>• "إزالة النص الأخير"</li>
                  <li>• "شيل هذا الكلام"</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-green-600">أوامر الإضافة</h4>
                <ul className="space-y-1 text-gray-600 dark:text-gray-300">
                  <li>• "أضف عنوان جديد"</li>
                  <li>• "اكتب نص جديد"</li>
                  <li>• "ضع هذا النص"</li>
                  <li>• مجرد التحدث بالنص</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-purple-600">أوامر التنسيق</h4>
                <ul className="space-y-1 text-gray-600 dark:text-gray-300">
                  <li>• "عنوان: العنوان هنا"</li>
                  <li>• "استبدل كلمة بأخرى"</li>
                  <li>• "غير النص"</li>
                  <li>• "خلي هذا عنوان"</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-red-600">أوامر التحكم</h4>
                <ul className="space-y-1 text-gray-600 dark:text-gray-300">
                  <li>• "توقف" - إيقاف التسجيل</li>
                  <li>• "استمرار" - وضع مستمر</li>
                  <li>• "خلاص" - إنهاء العملية</li>
                  <li>• "كفاية" - إيقاف</li>
                </ul>
              </div>
            </div>

            <div className="mt-4 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
              <p className="text-sm text-green-800 dark:text-green-200 arabic-text">
                <Zap className="w-4 h-4 inline ml-1" />
                <strong>ميزة ذكية:</strong> النظام يتعلم من سياق النص الحالي ويفهم الأوامر حتى لو لم تكن دقيقة!
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
