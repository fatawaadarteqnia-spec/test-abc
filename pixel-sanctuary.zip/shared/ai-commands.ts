export interface CommandAnalysisRequest {
  text: string;
  context?: string;
}

export interface CommandAnalysisResponse {
  isCommand: boolean;
  commandType: 'insert' | 'delete' | 'replace' | 'format' | 'control' | null;
  action: string;
  target?: string;
  content?: string;
  replacement?: string;
  confidence: number;
  explanation: string;
}

export interface AIError {
  error: string;
  message: string;
}
