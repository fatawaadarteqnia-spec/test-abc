import { RequestHandler } from "express";
import OpenAI from "openai";

export interface AIProvider {
  name: string;
  displayName: string;
  apiKey?: string;
  baseURL?: string;
  model: string;
  available: boolean;
  priority: number;
}

interface CommandAnalysisRequest {
  text: string;
  context?: string;
}

interface CommandAnalysisResponse {
  isCommand: boolean;
  commandType: 'insert' | 'delete' | 'replace' | 'format' | 'control' | null;
  action: string;
  target?: string;
  content?: string;
  replacement?: string;
  confidence: number;
  explanation: string;
  provider?: string;
}

// AI Providers Configuration
const AI_PROVIDERS: AIProvider[] = [
  {
    name: 'deepseek',
    displayName: 'DeepSeek (مجاني)',
    baseURL: 'https://api.deepseek.com/v1',
    model: 'deepseek-chat',
    apiKey: process.env.DEEPSEEK_API_KEY,
    available: !!process.env.DEEPSEEK_API_KEY,
    priority: 1
  },
  {
    name: 'gemini',
    displayName: 'Google Gemini',
    baseURL: 'https://generativelanguage.googleapis.com/v1beta',
    model: 'gemini-1.5-flash',
    apiKey: process.env.GEMINI_API_KEY,
    available: !!process.env.GEMINI_API_KEY,
    priority: 2
  },
  {
    name: 'openai',
    displayName: 'OpenAI GPT',
    model: 'gpt-3.5-turbo',
    apiKey: process.env.OPENAI_API_KEY,
    available: !!process.env.OPENAI_API_KEY,
    priority: 3
  },
  {
    name: 'claude',
    displayName: 'Anthropic Claude',
    baseURL: 'https://api.anthropic.com/v1',
    model: 'claude-3-haiku-20240307',
    apiKey: process.env.ANTHROPIC_API_KEY,
    available: !!process.env.ANTHROPIC_API_KEY,
    priority: 4
  },
  {
    name: 'groq',
    displayName: 'Groq (سريع)',
    baseURL: 'https://api.groq.com/openai/v1',
    model: 'llama-3.1-8b-instant',
    apiKey: process.env.GROQ_API_KEY,
    available: !!process.env.GROQ_API_KEY,
    priority: 5
  }
];

// Initialize clients for available providers
const aiClients: { [key: string]: any } = {};

AI_PROVIDERS.forEach(provider => {
  if (provider.available) {
    try {
      if (provider.name === 'openai' || provider.name === 'deepseek' || provider.name === 'groq') {
        aiClients[provider.name] = new OpenAI({
          apiKey: provider.apiKey,
          baseURL: provider.baseURL,
        });
      } else if (provider.name === 'gemini') {
        // Gemini uses different API structure
        aiClients[provider.name] = {
          apiKey: provider.apiKey,
          baseURL: provider.baseURL
        };
      } else if (provider.name === 'claude') {
        // Claude uses different API structure  
        aiClients[provider.name] = {
          apiKey: provider.apiKey,
          baseURL: provider.baseURL
        };
      }
      console.log(`✅ ${provider.displayName} initialized successfully`);
    } catch (error) {
      console.warn(`❌ Failed to initialize ${provider.displayName}:`, error);
      provider.available = false;
    }
  }
});

const SYSTEM_PROMPT = `أنت مساعد ذكي متخصص في تحليل الأوامر الصوتية العربية للتحكم في الوثائق.

مهمتك: تحليل النص المرسل وتحديد ما إذا كان:
1. أمراً للتحكم في الوثيقة (حذف، إضافة، تعديل، تنسيق)
2. نصاً عادياً يجب إدراجه في الوثيقة

أنواع الأوامر:
- delete: أوامر الحذف (امسح، احذف، إزالة، شيل)
- insert: أوامر الإضافة (أضف، اكتب، ضع)
- replace: أوامر الاستبدال (استبدل، غير، بدّل)
- format: أوامر التنسيق (عنوان، رأس، فقرة، قائمة)
- control: أوامر التحكم (توقف، استمرار، حفظ، خلاص، كفاية)

الرد يجب أن يكون JSON فقط:
{
  "isCommand": boolean,
  "commandType": "insert|delete|replace|format|control|null",
  "action": "وصف دقيق للعمل المطلوب",
  "target": "الهدف المحدد (اختياري)",
  "content": "المحتوى المطلوب (اختياري)",
  "confidence": رقم من 0 إلى 1,
  "explanation": "شرح مختصر"
}`;

// Try DeepSeek API
async function tryDeepSeek(text: string, context?: string): Promise<CommandAnalysisResponse | null> {
  if (!aiClients.deepseek) return null;

  try {
    const completion = await aiClients.deepseek.chat.completions.create({
      model: 'deepseek-chat',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: `النص: "${text}"${context ? `\nالسياق: "${context}"` : ''}` }
      ],
      temperature: 0.3,
      max_tokens: 500,
    });

    const response = completion.choices[0]?.message?.content;
    if (response) {
      const parsed = JSON.parse(response);
      return {
        ...parsed,
        provider: 'DeepSeek',
        explanation: parsed.explanation + ' (DeepSeek)'
      };
    }
  } catch (error) {
    console.log('DeepSeek failed:', error);
  }
  return null;
}

// Try Gemini API
async function tryGemini(text: string, context?: string): Promise<CommandAnalysisResponse | null> {
  if (!aiClients.gemini) return null;

  try {
    const response = await fetch(
      `${aiClients.gemini.baseURL}/models/gemini-1.5-flash:generateContent?key=${aiClients.gemini.apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: `${SYSTEM_PROMPT}\n\nالنص: "${text}"${context ? `\nالسياق: "${context}"` : ''}`
            }]
          }],
          generationConfig: {
            temperature: 0.3,
            maxOutputTokens: 500,
          }
        }),
      }
    );

    const data = await response.json();
    const responseText = data.candidates?.[0]?.content?.parts?.[0]?.text;
    
    if (responseText) {
      const parsed = JSON.parse(responseText);
      return {
        ...parsed,
        provider: 'Gemini',
        explanation: parsed.explanation + ' (Gemini)'
      };
    }
  } catch (error) {
    console.log('Gemini failed:', error);
  }
  return null;
}

// Try OpenAI API
async function tryOpenAI(text: string, context?: string): Promise<CommandAnalysisResponse | null> {
  if (!aiClients.openai) return null;

  try {
    const completion = await aiClients.openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: `النص: "${text}"${context ? `\nالسياق: "${context}"` : ''}` }
      ],
      temperature: 0.3,
      max_tokens: 500,
    });

    const response = completion.choices[0]?.message?.content;
    if (response) {
      const parsed = JSON.parse(response);
      return {
        ...parsed,
        provider: 'OpenAI',
        explanation: parsed.explanation + ' (OpenAI)'
      };
    }
  } catch (error) {
    console.log('OpenAI failed:', error);
  }
  return null;
}

// Try Groq API
async function tryGroq(text: string, context?: string): Promise<CommandAnalysisResponse | null> {
  if (!aiClients.groq) return null;

  try {
    const completion = await aiClients.groq.chat.completions.create({
      model: 'llama-3.1-8b-instant',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: `��لنص: "${text}"${context ? `\nالسياق: "${context}"` : ''}` }
      ],
      temperature: 0.3,
      max_tokens: 500,
    });

    const response = completion.choices[0]?.message?.content;
    if (response) {
      const parsed = JSON.parse(response);
      return {
        ...parsed,
        provider: 'Groq',
        explanation: parsed.explanation + ' (Groq - سريع)'
      };
    }
  } catch (error) {
    console.log('Groq failed:', error);
  }
  return null;
}

// Fallback analysis
function fallbackAnalysis(text: string): CommandAnalysisResponse {
  const cleanText = text.toLowerCase().trim();
  
  // Delete commands
  if (cleanText.includes('امسح') || cleanText.includes('احذف') || cleanText.includes('إزالة') || cleanText.includes('شيل')) {
    if (cleanText.includes('آخر') || cleanText.includes('أخير')) {
      return {
        isCommand: true,
        commandType: 'delete',
        action: 'حذف آخر فقرة',
        target: 'last',
        confidence: 0.8,
        explanation: 'تحليل أساسي - حذف آخر عنصر',
        provider: 'التحليل الأساسي'
      };
    }
    if (cleanText.includes('كل') || cleanText.includes('جميع')) {
      return {
        isCommand: true,
        commandType: 'delete',
        action: 'حذف جميع المحتوى',
        target: 'all',
        confidence: 0.9,
        explanation: 'تحليل أساسي - حذف جميع المحتوى',
        provider: 'التحليل الأساسي'
      };
    }
  }
  
  // Format commands
  if (cleanText.includes('عنوان') || cleanText.includes('رأس')) {
    const content = text.replace(/.*عنوان/i, '').trim();
    return {
      isCommand: true,
      commandType: 'format',
      action: 'إضافة عنوان',
      content: content || 'عنوان جديد',
      confidence: 0.9,
      explanation: 'تحليل أساسي - إضافة عنوان',
      provider: 'التحليل الأساسي'
    };
  }
  
  // Control commands
  if (cleanText.includes('توقف') || cleanText.includes('إيقاف') || cleanText.includes('خلاص') || cleanText.includes('كفاية')) {
    return {
      isCommand: true,
      commandType: 'control',
      action: 'إيقاف التسجيل',
      confidence: 0.95,
      explanation: 'تحليل أساسي - إيقاف',
      provider: 'التحليل الأساسي'
    };
  }
  
  // Default: regular text
  return {
    isCommand: false,
    commandType: null,
    action: 'إدراج النص',
    content: text,
    confidence: 0.9,
    explanation: 'تحليل أساسي - نص عادي',
    provider: 'التحليل الأساسي'
  };
}

// Main analysis function that tries providers in priority order
export const analyzeCommandMultiAI: RequestHandler = async (req, res) => {
  try {
    const { text, context } = req.body as CommandAnalysisRequest;

    if (!text || text.trim().length === 0) {
      return res.status(400).json({
        error: "النص مطلوب",
        message: "يجب إرسال نص لتحليله"
      });
    }

    // Get available providers sorted by priority
    const availableProviders = AI_PROVIDERS
      .filter(p => p.available)
      .sort((a, b) => a.priority - b.priority);

    console.log(`🤖 Available AI providers: ${availableProviders.map(p => p.displayName).join(', ')}`);

    // Try each provider in order
    for (const provider of availableProviders) {
      let result: CommandAnalysisResponse | null = null;

      switch (provider.name) {
        case 'deepseek':
          result = await tryDeepSeek(text, context);
          break;
        case 'gemini':
          result = await tryGemini(text, context);
          break;
        case 'openai':
          result = await tryOpenAI(text, context);
          break;
        case 'groq':
          result = await tryGroq(text, context);
          break;
      }

      if (result && result.confidence >= 0.7) {
        console.log(`✅ Success with ${provider.displayName}`);
        return res.json(result);
      }
    }

    // All AI providers failed, use fallback
    console.log('⚠️ All AI providers failed, using fallback analysis');
    const fallbackResult = fallbackAnalysis(text);
    return res.json(fallbackResult);

  } catch (error) {
    console.error('Multi-AI analysis error:', error);
    const fallbackResult = fallbackAnalysis(req.body.text);
    return res.json(fallbackResult);
  }
};

// Test individual provider
export const testProvider: RequestHandler = async (req, res) => {
  try {
    const { providerName } = req.params;
    const provider = AI_PROVIDERS.find(p => p.name === providerName);

    if (!provider) {
      return res.status(404).json({ error: "مقدم الخدمة غير موجود" });
    }

    if (!provider.available) {
      return res.json({
        success: false,
        error: "غير مكوّن",
        message: `مفتاح ${provider.displayName} غير مكوّن`
      });
    }

    // Test the provider with a simple command
    let result: CommandAnalysisResponse | null = null;

    try {
      switch (provider.name) {
        case 'deepseek':
          result = await tryDeepSeek('اختبار');
          break;
        case 'gemini':
          result = await tryGemini('اختبار');
          break;
        case 'openai':
          result = await tryOpenAI('اختبار');
          break;
        case 'groq':
          result = await tryGroq('اختبار');
          break;
      }

      if (result) {
        res.json({
          success: true,
          message: `${provider.displayName} يعمل بشكل صحيح`,
          confidence: result.confidence,
          response: result.explanation
        });
      } else {
        res.json({
          success: false,
          error: "فشل الاختبار",
          message: `${provider.displayName} لا يستجيب بشكل صحيح`
        });
      }
    } catch (error: any) {
      res.json({
        success: false,
        error: error.message || "خطأ غير معروف",
        message: `خطأ في ${provider.displayName}: ${error.message || 'غير محدد'}`
      });
    }

  } catch (error) {
    res.status(500).json({ error: "خطأ في اختبار مقدم الخدمة" });
  }
};

// Analyze with specific provider
export const analyzeWithProvider: RequestHandler = async (req, res) => {
  try {
    const { providerName } = req.params;
    const { text, context } = req.body as CommandAnalysisRequest;

    if (!text || text.trim().length === 0) {
      return res.status(400).json({
        error: "النص مطلوب",
        message: "يجب إرسال نص لتحليله"
      });
    }

    const provider = AI_PROVIDERS.find(p => p.name === providerName);

    if (!provider) {
      return res.status(404).json({ error: "مقدم الخدمة غير موجود" });
    }

    if (!provider.available) {
      return res.status(503).json({
        error: "مقدم الخدمة غير متاح",
        message: `${provider.displayName} غير مكوّن أو لا يعمل`
      });
    }

    let result: CommandAnalysisResponse | null = null;

    switch (provider.name) {
      case 'deepseek':
        result = await tryDeepSeek(text, context);
        break;
      case 'gemini':
        result = await tryGemini(text, context);
        break;
      case 'openai':
        result = await tryOpenAI(text, context);
        break;
      case 'groq':
        result = await tryGroq(text, context);
        break;
    }

    if (result) {
      res.json(result);
    } else {
      // Fallback to basic analysis
      const fallbackResult = fallbackAnalysis(text);
      fallbackResult.explanation = `فشل ${provider.displayName} - تم استخدام التحليل الأساسي`;
      res.json(fallbackResult);
    }

  } catch (error) {
    console.error('Provider-specific analysis error:', error);
    const fallbackResult = fallbackAnalysis(req.body.text);
    fallbackResult.explanation = "خطأ في الذكاء الاصطناعي - تم استخدام التحليل الأساسي";
    res.json(fallbackResult);
  }
};

// Get provider status (lightweight version without actual testing to avoid hanging)
export const getProviderStatus: RequestHandler = async (req, res) => {
  try {
    // Return status based on configuration only, not actual testing
    // Actual testing will be done on-demand when user clicks test button
    const basicStatus = AI_PROVIDERS.map(provider => ({
      name: provider.name,
      displayName: provider.displayName,
      available: provider.available,
      priority: provider.priority,
      configured: provider.available,
      working: provider.available, // Assume working if configured
      error: provider.available ? null : "غير مكوّن",
      lastTested: provider.available ? new Date().toISOString() : null
    }));

    res.json({
      providers: basicStatus,
      totalAvailable: basicStatus.filter(p => p.available).length,
      totalWorking: basicStatus.filter(p => p.working).length
    });

  } catch (error) {
    console.error('Error getting provider status:', error);
    res.status(500).json({
      error: 'خطأ في جلب حالة مقدمي الخدمات',
      providers: AI_PROVIDERS.map(p => ({
        name: p.name,
        displayName: p.displayName,
        available: p.available,
        priority: p.priority,
        configured: p.available,
        working: false,
        error: 'خطأ في النظام',
        lastTested: null
      })),
      totalAvailable: AI_PROVIDERS.filter(p => p.available).length,
      totalWorking: 0
    });
  }
};
